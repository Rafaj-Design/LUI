//
//  UIImageView+LUIImages.h
//
//  Created by Ondrej Rafaj on 08/06/2015.
//  Copyright (c) 2015 Ridiculous Innovations. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIImageView (LUIImages)

- (void)registerWithImageKey:(NSString *)key;


@end
