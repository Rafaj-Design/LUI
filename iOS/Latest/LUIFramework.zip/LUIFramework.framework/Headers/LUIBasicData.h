//
//  LUIBasicData.h
//
//  Created by Ondrej Rafaj on 20/05/2015.
//  Copyright (c) 2015 Ridiculous Innovations. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LUIBasicData : NSObject

@end
