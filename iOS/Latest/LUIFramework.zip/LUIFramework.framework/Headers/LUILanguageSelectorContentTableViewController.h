//
//  LUILanguageSelectorContentTableViewController.h
//
//  Created by Ondrej Rafaj on 31/05/2015.
//  Copyright (c) 2015 Ridiculous Innovations. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LUILanguageSelectorContentTableViewController : UITableViewController

- (void)reloadData;
- (void)close;


@end
